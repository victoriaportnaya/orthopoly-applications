# Real-data benchmark bundle

Install the Orthopoly Applications wheel from the website first. Then, from this extracted folder, run:

```bash
python3 -m pip install -r benchmark-requirements.txt
python3 benchmark_real_data.py > reproduced-results.json
```

`REPORT.md` explains the datasets, baselines, splits, and limits. `real-data-results.json` is the published output snapshot. The yearly sunspots data are bundled in `data/`; the other datasets are bundled with scikit-learn and NetworkX.
